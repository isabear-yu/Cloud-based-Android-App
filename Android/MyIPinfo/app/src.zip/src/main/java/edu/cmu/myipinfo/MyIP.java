package edu.cmu.myipinfo;
import android.os.AsyncTask;
import android.os.Build;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import androidx.annotation.RequiresApi;

public class MyIP {
    MainActivity ip = null;

    /*
     * search is the public GetPicture method.  Its arguments are the search term, and the InterestingPicture object that called it.  This provides a callback
     * path such that the pictureReady method in that object is called when the picture is available from the search.
     */
    public void search(String searchTerm, MainActivity ip) {
        this.ip = ip;
        new AsyncIPSearch().execute(searchTerm);
    }

    /*
     * AsyncTask provides a simple way to use a thread separate from the UI thread in which to do network operations.
     * doInBackground is run in the helper thread.
     * onPostExecute is run in the UI thread, allowing for safe UI updates.
     */
    private class AsyncIPSearch extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            return search(urls[0]);
        }

        protected void onPostExecute(String ipinfo) {
            ip.ipReady(ipinfo);
        }

        /*
         * Search Flickr.com for the searchTerm argument, and return a Bitmap that can be put in an ImageView
         */
        private String search(String searchTerm) {
            String ipURL = null;
//            ipURL = "https://ipinfo.io/" + searchTerm + "/geo";
//            https://frozen-dusk-72443.herokuapp.com/MyIP-1.0-SNAPSHOT/myIP?searchTerm=1.3.5.6
            ipURL = "https://whispering-reaches-48823.herokuapp.com/?searchTerm="+ searchTerm;
            System.out.println(ipURL);
            // At this point, we have the URL of the picture that resulted from the search.  Now load the image itself.
            try {
                return getRemoteIP(ipURL);
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Error");
                return null; // so compiler does not complain
            }

        }


        /*
         * Given a URL referring to an image, return a bitmap of that image
         */
        @RequiresApi(api = Build.VERSION_CODES.P)
        private String getRemoteIP(final String url) {
            String ipAdr = null;
            String city = null;
            String region = null;
            String country = null;
            String loc = null;
            String org = null;
            String postal = null;
            String timezone = null;
            try {
                HttpURLConnection conn ;
                URL myIP = new URL (url);
                conn = (HttpURLConnection)myIP.openConnection();
                conn.setRequestMethod("GET");
                int status = conn.getResponseCode();


                InputStream stream = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                StringBuilder responce = new StringBuilder();
                String line=null;
                while((line=reader.readLine())!=null)
                {
                    responce.append(line);
                    responce.append("\r");
                }
                reader.close();
                String result = responce.toString();
                System.out.print(result);
                JSONObject objectIp = new JSONObject(result);
                System.out.println(objectIp);
                ipAdr = objectIp.getString("ip");
                city = objectIp.getString("city");
                region = objectIp.getString("region");
                country = objectIp.getString("country");
                loc = objectIp.getString("loc");
                org = objectIp.getString("org");
                postal = objectIp.getString("postal");
                timezone = objectIp.getString("timezone");
                System.out.println("timezone:"+ timezone);
            } catch (IOException | JSONException e) {
                e.printStackTrace();
                return "Please enter the valid IP";
            }
            System.out.println(ipAdr+ "@" + city +"@"+ region +"@"+country+ "@"+loc+ "@"+org + "@"+ postal +"@"+ timezone);
            return ipAdr+ "@" + city +"@"+ region +"@"+country+ "@"+loc+ "@"+org + "@"+ postal +"@"+ timezone;
        }
    }
}
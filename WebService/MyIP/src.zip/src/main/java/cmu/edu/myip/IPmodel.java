package cmu.edu.myip;

import java.util.HashMap;
import java.util.Map;
import javax.swing.text.Document;
import com.mongodb.client.MongoCursor;

public class IPmodel {
    HashMap<String, Integer> searchIP = new HashMap<>();
    Integer ipCount;
    public String doCalSearch( String ip) {
            ipCount =searchIP.get(ip);
            System.out.println(ip);
            if(ipCount == null) {
                searchIP.put(ip, 0);
            }
            int tmp = searchIP.get(ip) + 1;
            searchIP.put(ip,tmp );
            System.out.println("Num of search:" + searchIP.get(ip));
        // Iterating HashMap through for loop

        Map.Entry<String, Integer> maxEntry = null;
        //https://stackoverflow.com/questions/5911174/finding-key-associated-with-max-value-in-a-java-map
        for (Map.Entry<String, Integer> entry : searchIP.entrySet())
        {
            if (maxEntry == null || entry.getValue() > maxEntry.getValue())
            {
                maxEntry = entry;
            }
        }

        return maxEntry.getKey();
    }




}

package cmu.edu.myip;

import java.io.PrintWriter;
import static com.mongodb.client.model.Filters.lt;

import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.mongodb.MongoException;
import org.bson.Document;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.json.JSONException;
import org.json.JSONObject;
import com.mongodb.client.result.InsertOneResult;
import org.bson.types.ObjectId;
import org.bson.conversions.Bson;
import java.util.ArrayList;
import java.util.Date;
import static com.mongodb.client.model.Filters.eq;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import com.mongodb.client.MongoCursor;
import org.json.JSONObject;
import java.text.SimpleDateFormat;

@WebServlet(name = "myIP", urlPatterns = {"/","/dashboard"})
public class MyIP extends HttpServlet {
    IPmodel model = new IPmodel();
    boolean firstTime = true;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        // determine what type of device our user is
        String nextView = "result.jsp";
        String ua = request.getHeader("User-Agent");
//        String searchTerm = request.getParameter("searchTerm");
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;

            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }

        String uri = "mongodb+srv://ooisabellelol:cute0128@cluster0.kfo8q.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

        URL myIP;
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("MyIpInfo");
            MongoCollection<Document> collection = database.getCollection("ipInfo");
//                Document doc = collection.find(eq("title", "Back to the Future")).first();


            try {
                String numOfSearch = null;

                Bson projectionFields = Projections.fields(
                        Projections.include("ip"),
                        Projections.excludeId());

                MongoCursor<Document> cursor  = collection.find()
                        .projection(projectionFields)
                        .sort(Sorts.descending("title")).iterator();


                try {
                    while(cursor.hasNext() && firstTime == true) {
                        JSONObject ipAdrr = new JSONObject(cursor.next().toJson());
                        numOfSearch = model.doCalSearch(ipAdrr.getString("ip"));
                    }
                    firstTime =false;
                } finally {
                    cursor.close();
                }
                System.out.println(numOfSearch);
                request.setAttribute("numOfSearch",numOfSearch);
            } catch (MongoException | JSONException me) {
                System.err.println("Unable to insert due to an error: " + me);
            }
        }
        if (request.getParameter("searchTerm")!=null){
        try {
            String searchTerm = request.getParameter("searchTerm");
            myIP = new URL("https://ipinfo.io/" + searchTerm + "/geo");
            System.out.println(myIP.toString());
            HttpURLConnection conn = (HttpURLConnection) myIP.openConnection();
            conn.setRequestMethod("GET");


            InputStream stream = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            StringBuilder responce = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                responce.append(line);
                responce.append("\r");
            }
            reader.close();

            String ipAdress = responce.toString();

            System.out.println("open");
            System.out.println("close");

            out.print(responce);
            JSONObject objectIp = new JSONObject(ipAdress);
            System.out.println(objectIp.toString());


            String ipAdr = objectIp.getString("ip");
            String city = objectIp.getString("city");
            String region = objectIp.getString("region");
            String country = objectIp.getString("country");
            String loc = objectIp.getString("loc");
//            String org = objectIp.getString("org");
            String postal = objectIp.getString("postal");
            String timezone = objectIp.getString("timezone");
            ArrayList<String> att = new ArrayList<>();


            System.out.println("My ip: " + ipAdr);
            System.out.println("My city " + city);
            System.out.println("My region " + region);
            System.out.println("My country: " + country);
            System.out.println("My loc " + loc);
//            System.out.println("My org " + org);
            System.out.println("My postal: " + postal);
            System.out.println("My timezone " + timezone);

            try (MongoClient mongoClient = MongoClients.create(uri)) {
                MongoDatabase database = mongoClient.getDatabase("MyIpInfo");
                MongoCollection<Document> collection = database.getCollection("ipInfo");
//                Document doc = collection.find(eq("title", "Back to the Future")).first();


                try {
                    InsertOneResult result1 = collection.insertOne(new Document()
                                    .append("_id", new ObjectId())
                                    .append("ip", searchTerm)
                                    .append("city", city)
                                    .append("region", region)
                                    .append("country", country)
                                    .append("loc", loc)
//                            .append("org:", org)
                                    .append("postal", postal)
                                    .append("timezone", timezone)
                    );
                    String numOfSearch = null;
                    System.out.println("Success! Inserted document id: " + result1.getInsertedId());

                    Bson projectionFields = Projections.fields(
                            Projections.include("ip"),
                            Projections.excludeId());

                    MongoCursor<Document> cursor  = collection.find()
                            .projection(projectionFields)
                            .sort(Sorts.descending("title")).iterator();


                    try {
                        numOfSearch = model.doCalSearch(searchTerm);
//                        while(cursor.hasNext() && firstTime == true) {
//                            JSONObject ipAdrr = new JSONObject(cursor.next().toJson());
//                            numOfSearch = model.doCalSearch(ipAdrr.getString("ip"));
//                        }
                        firstTime =false;
                    } finally {
                        cursor.close();
                    }
                    System.out.println(numOfSearch);
                    request.setAttribute("numOfSearch",numOfSearch);
                } catch (MongoException | JSONException me) {
                    System.err.println("Unable to insert due to an error: " + me);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


        if(request.getServletPath().contains("/dashboard")){
            System.out.println("dashboard!");
            nextView = "result.jsp";
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }


    }



}

